package br.com.javamagazine.onzevencedor.entity;

public enum Posicao {
	Goleiro, Zagueiro, Lateral, Volante, Ponta, Meio_Campo, Atacante; 
}
