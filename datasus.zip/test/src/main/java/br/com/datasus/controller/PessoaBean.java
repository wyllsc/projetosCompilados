package br.com.datasus.controller;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import javax.faces.event.AjaxBehaviorEvent;

import br.com.datasus.entity.Pessoa;
import br.com.datasus.entity.Sexo;
import br.com.datasus.service.PessoaService;

@ManagedBean(name = "pessoaBean")
@ViewScoped
public class PessoaBean extends BaseBean {

	private static final long serialVersionUID = 3834645473369932759L;

	@ManagedProperty("#{pessoaService}")
	private PessoaService model;
	
	private Pessoa pessoa;
	private List<Pessoa> pessoas;
	private List<Sexo> sexo;
	private String nomePessoa;

	private Long idSexo;

	private Long idSexoFiltro;
	private String nomePessoaFiltro;

	public void filtrarPessoaPorFiltro(AjaxBehaviorEvent event) {
		if (idSexoFiltro != null || !nomePessoaFiltro.equals("")) {
			pessoas = model.getPessoasPorFiltro(idSexoFiltro, nomePessoaFiltro);
		} else {
			pessoas = model.getAllPessoas();
		}
	}

	public void salvar() {
		Sexo sexo = new Sexo();
		sexo.setId(idSexo);
		pessoa.setSexo(sexo);

		pessoa = model.createPessoa(pessoa);
		pessoa = new Pessoa();
		addInfoMessage("Pessoa criado com sucesso.");
	}

	public void cancelar() {
		idSexoFiltro = null;
		nomePessoaFiltro = null;
		pessoas = new ArrayList<Pessoa>();
	}

	// GETTERS E SETTERS

	public List<Pessoa> getPessoas() {
		if (pessoas == null) {
			pessoas = model.getAllPessoas();
		}
		return pessoas;
	}

	public PessoaService getModel() {
		return model;
	}

	public void setModel(PessoaService model) {
		this.model = model;
	}

	public Pessoa getPessoa() {
		return pessoa;
	}

	public void setPessoa(Pessoa pessoa) {
		this.pessoa = pessoa;
	}

	public Long getIdSexo() {
		return idSexo;
	}

	public void setIdSexo(Long idSexo) {
		this.idSexo = idSexo;
	}

	public List<Sexo> getSexo() {
		if (sexo == null) {
			sexo = model.getAllSexo();
		}
		return sexo;
	}

	public void setSexo(List<Sexo> sexo) {
		this.sexo = sexo;
	}

	public String getNomePessoa() {
		return nomePessoa;
	}

	public void setNomePessoa(String nomePessoa) {
		this.nomePessoa = nomePessoa;
	}

	public void setPessoas(List<Pessoa> pessoas) {
		this.pessoas = pessoas;
	}
}
