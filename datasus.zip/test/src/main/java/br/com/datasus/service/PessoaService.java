package br.com.datasus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.datasus.dao.PessoaDAO;
import br.com.datasus.entity.Pessoa;
import br.com.datasus.entity.Sexo;

@Service("pessoaService")
public class PessoaService {

	@Autowired
	private PessoaDAO dao;

	public List<Pessoa> getAllPessoas(){
		return dao.findAll();
	}

	public List<Sexo> getAllSexo(){
		return dao.findAllSexo();
	}
	public Pessoa createPessoa(Pessoa pessoa){
		return dao.create(pessoa);
	}
	public void updatePessoa(Pessoa pessoa){
		dao.update(pessoa);
	}
	public void deletePessoa(Pessoa pessoa){
		dao.delete(pessoa);
	}

	public List<Pessoa> getPessoasPorFiltro(Long idSexoFiltro, String nomePessoaFiltro) {
		return dao.consultarPessoasPorFiltro(idSexoFiltro, nomePessoaFiltro);
	}
}
