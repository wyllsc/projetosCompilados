package br.com.datasus.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import br.com.datasus.entity.Pessoa;
import br.com.datasus.entity.Sexo;

@Repository("pessoaDao")
public class PessoaDAO {
	
	@PersistenceContext
	protected EntityManager entityManager;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	public List<Pessoa> findAll(){
		String jpql = " SELECT pes from Pessoa pes order by pes.nome";
		Query query = entityManager.createQuery(jpql);
		List<Pessoa> pessoas = (List<Pessoa>) query.getResultList();
		return pessoas;
	}

	@SuppressWarnings("unchecked")
	@Transactional(readOnly=true)
	public List<Sexo> findAllSexo(){
		String jpql = " SELECT sex from Sexo sex order by sex.descricao";
		Query query = entityManager.createQuery(jpql);
		List<Sexo> sex = (List<Sexo>) query.getResultList();
		return sex;
	}
	

	@Transactional
	public Pessoa create(Pessoa pessoa){
		entityManager.persist(pessoa);
		return pessoa;
	}

	@Transactional
	public void update(Pessoa pessoa){
		entityManager.merge(pessoa);
	}

	@Transactional
	public void delete(Pessoa pessoa){
		pessoa = entityManager.find(Pessoa.class, pessoa.getId());
		entityManager.remove(pessoa);
	}

	@SuppressWarnings("unchecked")
	public List<Pessoa> consultarPessoasPorFiltro(Long idSexoFiltro, String nomePessoaFiltro) {
		
		String jpql = "";
		String meio = "";
		
		if (idSexoFiltro != null) {
			String sexo = " and pes.sexo.id ="+idSexoFiltro+" ";
			meio = meio+sexo;
		}
		if (!nomePessoaFiltro.equals("")) {
			String nome = " and pes.nome like '%'||"+nomePessoaFiltro+"||'%' ";
			meio = meio+nome;
		}
		String inicio = " SELECT pes from Pessoa pes where 1 = 1";
		String fim = " order by pes.nome";
		
		if(meio.equals("")){
			jpql = inicio+fim;
		}else{
			jpql = inicio+meio+fim;
		}
		
		Query query = entityManager.createQuery(jpql);
		List<Pessoa> lista = (List<Pessoa>) query.getResultList();
		return lista;
		
	}
}